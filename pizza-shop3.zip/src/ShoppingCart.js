import React, { Component } from 'react';
import { GridList, GridTile } from 'material-ui/GridList';
import { IconButton, Paper, Chip,Typography, Icon, RaisedButton  } from 'material-ui';
import {
  Table,
  TableBody,
  TableHeader,
  TableHeaderColumn,
  TableRow,
  TableRowColumn,
  TableFooter,
} from 'material-ui/Table';
import AddIcon from 'material-ui/svg-icons/action/favorite';
import './css/style.css';
import PizzaCompOrder from './PizzaCompOrder';
import pizzas from './pizzas.json'
import { Button } from "react-bootstrap";



class ShoppingCart extends React.Component {
    
    constructor(props) {
        super(props);

        this.state = {
            total: 0
        };

    this.calculateTotal = this.calculateTotal.bind(this);
    this.removeItem = this.removeItem.bind(this);
    }

    componentWillMount() {
        this.calculateTotal();
    }    
    
     calculateTotal() {
        var total2 = 0;
        for(var i = 0; i < this.props.pizzasCart.length; i++) {
            total2 += parseInt(this.props.pizzasCart[i].price)* this.props.pizzasCart[i].count;
        }

        this.setState({
            total: total2 
        });
      }


      removeItem(elem) {
          this.props.removeItem(elem);
          this.calculateTotal();
      }

    render() {
    
        return( 
        
            <div>
    
            { this.props.pizzasCart.length == 0 ? (
                
                <Paper className = "cartNoItems" >
                There are no products in the shopping cart!
                </Paper>
               
            ) : (
            <div className ="pizzaMenu">
            
            <Paper>
            <Table bodyStyle={{overflow:'visible'}} style={{ tableLayout: 'auto' }} fixedHeader={false}>
                <TableBody displayRowCheckbox ={false}>

                     <TableRow className = "headerOrderList" key = "42">
                     <TableRowColumn className = "cellTable"> Pizza pic </TableRowColumn>
                        <TableRowColumn className = "cellTable" >Pizza type</TableRowColumn>
                         <TableRowColumn className = "cellTable" >Base</TableRowColumn>
                        <TableRowColumn className = "cellTable"> Price </TableRowColumn>
                        <TableRowColumn className = "cellTable"> Pieces ordered </TableRowColumn>
                        <TableRowColumn> </TableRowColumn>
                    </TableRow>
                    {
                    this.props.pizzasCart.map((pizza2) => (
                        <PizzaCompOrder pizza = {pizza2} removeItem = {this.removeItem} />
                    ))
                }
                </TableBody>
                <TableFooter displayRowCheckbox = {false} >
                    <TableRow> 
                        <TableRowColumn  className = "cellFooter"> Total price of your order: {this.state.total} lei</TableRowColumn>
                    </TableRow>
                </TableFooter>
                    

            </Table>

        </Paper>

     
        <RaisedButton className = "sendOrder" 
        label = "Send Order"
        icon = {<AddIcon />}
        labelPosition = "after"
        primary = {true}
         />
      

             </div>
            )
            
            }
            </div>
        
           
        );
    }

}



export default ShoppingCart;