import React, { Component } from 'react';
import { GridList, GridTile,ListSubheader } from 'material-ui/GridList';
import { IconButton, Paper, Chip } from 'material-ui';
import AddIcon from 'material-ui/svg-icons/action/favorite';
import Subheader from 'material-ui/Subheader';
import './css/style.css';
import PizzaComp from './PizzaComp';
import pizzasData from './pizzas.json'

import {MuiThemeProvider} from 'material-ui/styles/'
import theme from 'material-ui/styles/baseThemes/lightBaseTheme'


class PizzaMenu extends React.Component {
    
    constructor(props){
        super(props);
        
    this.menuAddtoCart = this.menuAddtoCart.bind(this);
    this.setBase = this.setBase.bind(this);
    }

    menuAddtoCart(elem) {
        this.props.addToCart(elem);

    }

    setBase(base) {
        this.props.setBase(base);
    }

    render() {

        var pizzas = pizzasData;
        for (var i = 0; i < pizzasData.length; i++) {
            pizzas.count = 0;
        }

        return( 
            <div> 
                <div className ="mainTitle"> Our Pizza Menu </div>
            <MuiThemeProvider theme = {theme}>
            
            <GridList className ="pizzaMenu" cols = {1} cellHeight = {400} >
            
                {
                    pizzas.map((pizza2) => (
                        <PizzaComp key = {pizza2.id} pizza = {pizza2} addToCart = {this.menuAddtoCart}
                        setBase = {this.setBase} baseSelected = {this.props.baseSelected} />
                        
                    ))
                }

            </GridList>
          
            </MuiThemeProvider>
            </div>
        );
    }

}


export default PizzaMenu;