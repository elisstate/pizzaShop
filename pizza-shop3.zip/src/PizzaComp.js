import React, { Component } from 'react';
import { GridList, GridTile } from 'material-ui/GridList';
import { IconButton, Paper, Chip } from 'material-ui';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import AddIcon from 'material-ui/svg-icons/action/favorite';
import './css/style.css';


class PizzaComp extends React.Component {
    constructor(props) {
        super(props);
     
     
     this.handleAddToCart = this. handleAddToCart.bind(this)
     this.selectBase = this.selectBase.bind(this)
    }


    handleAddToCart() {
        if(this.props.baseSelected == false) {
            alert("Please select a base for your pizza!");
        }
        else {
            this.props.addToCart(this.props.pizza);
        }
      
    }

    selectBase(event) {
        this.props.setBase(event);  
    }
    


    render() {
        return (
        <GridTile 
                key = {this.props.pizza.id} title = {this.props.pizza.name} 
                subtitle = {this.props.pizza.price}
                actionIcon = {
                    <IconButton tooltip = "Add to shopping cart" tooltipPosition ="top-left" onClick = {this.handleAddToCart} >
                    <AddIcon color = "pink"/>
                    </IconButton>
                } >

        

                <Paper zDepth = {1}  >
                    <div className = "Toppings">  Bases: 
                         {this.props.pizza.base.map( (base) =>
                            <Chip toggle = {true} clickable = {true} style = {{margin: 5}} onClick={() => this.selectBase(base.name)} key= {base.id} 
                             >
                             {base.name}
                            </Chip>
                            )} 
                    </div>
                    <br />
                    <div className = "Toppings">  Toppings: 
                         {this.props.pizza.toppings.map( (topping) =>
                            <Chip style = {{margin: 5}} > 
                                {topping}
                            </Chip>
                            )} 
                    </div>
                </Paper>
                        
        </GridTile>
        );
        
    }

}

export default PizzaComp;