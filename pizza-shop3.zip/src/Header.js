import React, { Component }  from 'react';
import { Navbar, Nav, NavItem, Button, FormGroup} from "react-bootstrap";
import {  Link } from 'react-router-dom';


import IconButton from 'material-ui/IconButton';
import { Toolbar, ToolbarGroup} from  'material-ui/Toolbar';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import AddIcon from 'material-ui/svg-icons/action/shopping-basket';



class Header extends Component {
    constructor(props) {
        super(props);

           
    }


    render() {
 
        return (
            <MuiThemeProvider>
            <Toolbar className = "HeaderComp" color="secondary">
            <Link to ="/home">
            <ToolbarGroup>
            <h1> Pizza Shop </h1>
            </ToolbarGroup>
            </Link>

           
                {
                this.props.isLogged ? 
                (
                <ToolbarGroup>
                <Link to = "/logout">
                    <Button bsStyle="primary" type="submit" onClick ={this.props.handleLog} > Logout </Button>
                </Link>
                
                <Link to = "/shoppingCart">
                     <IconButton tooltip = "Shopping Cart" tooltipPosition ="left-center" >
                    <AddIcon color = "black" />
                    </IconButton>
                </Link>
                </ToolbarGroup>
                ) : (
                   <ToolbarGroup> 
                  <Link to = "/login">
                    <Button type="submit"> Login </Button>
                </Link>
                </ToolbarGroup>  
                )
                }

            </Toolbar>
            
             </MuiThemeProvider>
        );
    }
}

export default Header;