import React, { Component } from 'react';
import { GridList, GridTile } from 'material-ui/GridList';
import { IconButton, Paper, Chip } from 'material-ui';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import RemoveIcon from 'material-ui/svg-icons/action/delete';
import {
  Table,
  TableBody,
  TableHeader,
  TableHeaderColumn,
  TableRow,
  TableRowColumn,
} from 'material-ui/Table';

import './css/style.css';
import { withStyles } from 'material-ui/styles';


class PizzaComp extends React.Component {
    constructor(props) {
        super(props);
     
     this.handleRemoveFromCart = this. handleRemoveFromCart.bind(this)
    }


   handleRemoveFromCart() {
        this.props.removeItem(this.props.pizza);
      
    }
    


    render() {

      

        return (

        <TableRow key = {this.props.pizza.id} >
            <TableRowColumn>
            Testt
             </TableRowColumn>
             <TableRowColumn className = "cellTable">
                 {this.props.pizza.name}
             </TableRowColumn>

             <TableRowColumn className = "cellTable">
                 {this.props.pizza.baseSel}
             </TableRowColumn>

             <TableRowColumn className = "cellTable">
                 {this.props.pizza.price} 
            </TableRowColumn>
            
            <TableRowColumn className = "cellTable"> 
            
                {this.props.pizza.count}
            
            </TableRowColumn>
            <TableRowColumn className = "cellTable"> 
                { 
                <IconButton tooltip = "Remove one item" tooltipPosition ="center"
                onClick = {this.handleRemoveFromCart}>
                    <RemoveIcon color = "orange"/>
                    </IconButton>} </TableRowColumn>
        </TableRow> 



        );   
    }

}

export default PizzaComp;