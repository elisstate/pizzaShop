import React, { Component } from 'react';
import { Button, FormGroup, FormControl, ControlLabel, Row, Col } from "react-bootstrap";
import { BrowserRouter as Router, Route, Link } from 'react-router-dom';

import RaisedButton from 'material-ui/RaisedButton';
import TextField from 'material-ui/TextField';

class Login extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            username: "",
            password: ""
        }

        this.handleChangePass = this.handleChangePass.bind(this);
        this.handleChangeUsername = this.handleChangeUsername.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
    }

     handleChangeUsername (event) {
        this.setState({
            username: event.target.value });
    }

    handleChangePass (event) {
        this.setState({
            password: event.target.value });
    }

    handleSubmit (event) {
       event.preventDefault();
    }

    validateForm() {
        return this.state.username.length > 0 && this.state.password.length > 0;
    }


    render() {
      
        return(
            <div className = "LoginBox"> 
                  <form>
                        <FormGroup controlId = "user" >
                          <ControlLabel> Username: </ControlLabel>
                          <FormControl autoFocus type="textarea" value = {this.state.username}
                          onChange = {this.handleChangeUsername} />
                        </FormGroup> 
                        <br />
                        <FormGroup controlId = "password"  > 
                            <ControlLabel> Password: </ControlLabel>
                            <FormControl autoFocus type="password" value = {this.state.password}
                            onChange = {this.handleChangePass}
                           />
                        </FormGroup>

                        <Link to="/home">
                        <Button disabled={!this.validateForm()}  onClick = {this.props.handleLog}>
                            Login
                        </Button>
                        </Link>
                      
                </form>
            </div>
        );
    }
        
}

export default Login;
