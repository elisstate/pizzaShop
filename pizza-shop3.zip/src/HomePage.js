import React, { Component } from 'react';
import { Link, Route, Switch, BrowserRouter } from 'react-router-dom';
import Header from "./Header";
import Login from "./Login";
import PizzaMenu from "./PizzaMenu";
import ShoppingCart from "./ShoppingCart";
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';


class HomePage extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            isLogged: false,
            pizzasCart: [],
            counter: [],
            baseSelected: false,
            base: ""
        }
        this.handleLog = this.handleLog.bind(this)
        this.addToCart = this.addToCart.bind(this)
        this.removeFromCart = this.removeFromCart.bind(this)
        this.setBase = this.setBase.bind(this)
           
    }


    handleLog() {
        this.setState (prevState =>  ({
            isLogged: !prevState.isLogged
        }));
    }


    setBase(newBase) {
        this.setState ({
                base: newBase,
                baseSelected: true
            });
        console.log(newBase);
    }

    addToCart(elem) {
        var aux = false;
        var i = 0;
        for (i = 0; i < this.state.pizzasCart.length; i++) {
            if (this.state.pizzasCart[i].id == elem.id) {
                aux = true;
                break;
            }
        }

        if (aux == false) {
            var newelem = elem;
            newelem.count = 1;
            newelem.baseSel = this.state.base

            this.setState ({
                pizzasCart: this.state.pizzasCart.concat([newelem]),
                base: "",
                baseSelected: false
               
            });
        }

        else {
            let newState = this.state.pizzasCart.slice();
            newState.baseSel = this.state.base
            if (typeof newState[i].count ==="undefined") {
                newState[i].count = 2;
            }
            else {
                 newState[i].count++;
            }
            this.setState ({
                pizzasCart: newState,
                base: "",
                baseSelected: false
            }); 
        
        }
    }




    removeFromCart(elem) {
  
        var i = 0;
        for (i = 0; i < this.state.pizzasCart.length; i++) {
            if (elem.id == this.state.pizzasCart[i].id)  {
             
                if (typeof this.state.pizzasCart[i].count === "undefined" || this.state.pizzasCart[i].count == 1) {
                    var newState = this.state.pizzasCart;
                    newState.splice(i,1);
                    this.setState({
                        pizzasCart: newState
                    });
                   
                }

                else {
                    let newState = this.state.pizzasCart.slice();
                    newState[i].count--;
                    this.setState ({
                pizzasCart: newState
            }); 
        
                    
                }
                
                break;
            }
        }
    }


    render() {
    

        return (
            <div>
                <MuiThemeProvider >
                <BrowserRouter>
                    <div>
                        <Header isLogged = {this.state.isLogged} handleLog = {this.handleLog} />
                        <Route exact path = "/login" render = {() => 
                            <Login isLogged = {this.state.isLogged} handleLog = {this.handleLog} /> } />
                        <Route exact path = "/home" render = { () =>
                            <PizzaMenu addToCart = {this.addToCart} setBase = {this.setBase} 
                            baseSelected = {this.state.baseSelected}/> } />
                        <Route exact path = "/shoppingCart" render = {() =>
                            <ShoppingCart  pizzasCart = {this.state.pizzasCart} removeItem = {this.removeFromCart}/>} />
                    </div>
                </BrowserRouter>
                </MuiThemeProvider >
           
            </div>
        )
    }
        
}

export default HomePage;
